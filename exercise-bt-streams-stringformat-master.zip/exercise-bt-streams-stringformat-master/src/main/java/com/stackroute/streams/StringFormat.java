package com.stackroute.streams;

import java.util.List;

public class StringFormat {

    //write logic to find the format for given list and return result
    public String findStringFormat(List<Integer> input) {
        return null;
    }
}
